#!/bin/sh
PASSFILE="$(dirname $0)/$username/passwd"
#LOG_FILE="/openvpn-passwd.log"
#TIME_STAMP=`date "+%Y-%m-%d %T"`
#if [ ! -r "${PASSFILE}" ]; then
#  echo "${TIME_STAMP}: Could not open password file \"${PASSFILE}\" for reading." >> ${LOG_FILE}
 # exit 1
#fi
CORRECT_PASSWORD=`cat $(dirname $0)/$username/passwd`
#if [ "${CORRECT_PASSWORD}" = "" ]; then 
#echo "${TIME_STAMP}: User does not exist: username=\"${username}\", password=\"${password}\"." >> ${LOG_FILE}
 # exit 1
#fi
if [ "${password}" = "${CORRECT_PASSWORD}" ]; then 
 # echo "${TIME_STAMP}: Successful authentication: username=\"${username}\"." >> ${LOG_FILE}
if [ "`expr  \`cat $(dirname $0)/$username/data\``" -gt 0 ] ;then
if [ "`expr  \`cat $(dirname $0)/$username/sj\``" -gt 0 ] ;then
  exit 0
fi
fi
fi
#echo "${TIME_STAMP}: Incorrect password: username=\"${username}\", password=\"${password}\"." >> ${LOG_FILE}
exit 1
