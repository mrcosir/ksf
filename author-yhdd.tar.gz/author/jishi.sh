#!/bin/bash
for file in `find /etc/openvpn/author -name sj`
do 
sed -i 's/[0-9]*/'$(expr $(cat $file) - 1 )'/' $file
done
