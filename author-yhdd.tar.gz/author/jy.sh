for data in `ls */data | sed 's/\/data//g'`;do
if [ "`expr  \`cat $data/data\``" -gt 0 ] ;then
if [ "`expr  \`cat $data/sj\``" -gt 0 ] ;then
rm -rf /etc/openvpn/author/$data