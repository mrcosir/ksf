for data in `ls */data | sed 's/\/data//g'`;do
printf "%-15s%8s%15s\n" "号""$data" 剩"`cat $data/data`M"  时"`cat $data/sj`"
done