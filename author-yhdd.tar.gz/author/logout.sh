#!/bin/sh
_used="`expr $bytes_received + $bytes_sent`"
_used="`expr $_used / 1024 / 1024`"
echo "`expr  \`cat $(dirname $0)/$username/data\` -  $_used`"  >$(dirname $0)/$username/data
