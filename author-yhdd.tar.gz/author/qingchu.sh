#!/bin/bash
echo "检测是否有账号时间或流量用尽"
echo "..........."
if [ "`expr  \`cat $(dirname $0)/$username/data\``" -gt 0 ] ;then
if [ "`expr  \`cat $(dirname $0)/$username/sj\``" -gt 0 ] ;then
  rm -rf /etc/openvpn/author/$username
fi
fi

echo 
echo "完成清除"
