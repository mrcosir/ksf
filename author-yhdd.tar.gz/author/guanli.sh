#!/bin/bash
echo 
echo "--------------------------------"
echo "欢迎使用康师傅免流™流量控制程序"
echo "by：mr haohao"
echo "--------------------------------"
cd /etc/openvpn/author/
echo 
echo "查询账号密码流量时间输入：1"
echo 
echo "查询账号流量时间输入：2"
echo 
echo "添加账号输入：3"
echo 
echo "连续添加账号输入：4"
echo 
echo "删除账号输入：5"
echo
read -p "请选择功能:" CMD
case "$CMD" in
1)
  echo "查询账号密码流量时间"
  echo "------------------------------"
  ./data.sh
;;
2)
  echo "查询账号流量时间"
  echo "------------------------------"
  ./data2.sh
;;
3)
  echo "添加账号"
  echo "------------------------------"
  ./tianjia.sh
;;
4)
  echo "连续添加账号"
  echo "------------------------------"
  ./lxtianjia.sh
;;
5)
  echo "删除账号"
  echo "------------------------------"
  ./shanchu.sh
;;
*)
  echo "无效退出"
esac
