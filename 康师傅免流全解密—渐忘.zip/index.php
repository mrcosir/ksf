<?php#www.ymazz.com QQ:80121457
header("location: ./user/login.php"); 