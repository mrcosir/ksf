<?php 
include 'header.php';
?>


        <!--body wrapper start-->
        <div class="wrapper">
            <div class="row">
                <div class="col-md-6">
                    <!--statistics start-->
                    <div class="row state-overview">
                        <div class="col-md-6 col-xs-12 col-sm-6">
                            <div class="panel purple">
                                <div class="symbol">
                                    <i class="fa fa-gavel"></i>
                                </div>
                                <div class="state-value">
                                    <div class="value"><?php echo $count?></div>
                                    <div class="title">注册用户</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-xs-12 col-sm-6">
                            <div class="panel red">
                                <div class="symbol">
                                    <i class="fa fa-tags"></i>
                                </div>
                                <div class="state-value">
                                    <div class="value"><?php echo $count2?></div>
                                    <div class="title">状态正常</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row state-overview">
                    	<div class="col-md-6 col-xs-12 col-sm-6">
                            <div class="panel green">
                                <div class="symbol">
                                    <i class="fa fa-eye"></i>
                                </div>
                                <div class="state-value">
                                    <div class="value"><?php //echo $DB->
                                            //在线人数接口
											$str=file_get_contents('../res/openvpn-status.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
											echo $onlinenum = (int)((substr_count($str,date('Y'))-1)/2);
                                            ?></div>
                                    <div class="title"> 在线人数</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-xs-12 col-sm-6">
                            <div class="panel blue">
                                <div class="symbol">
                                    <i class="fa fa-money"></i>
                                </div>
                                <div class="state-value">
                                    <div class="value"><?php echo date( "H:i") ?></div>
                                    <div class="title"> 现在时间</div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <!--statistics end-->
                </div>
                <div class="col-md-6">
                    <!--more statistics box start-->
                    <div class="panel deep-purple-box">
                        <div class="panel-body">
                            <div class="row rowgg">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <ul class="bar-legend">
                                        <li><span class="blue"></span>官方公告：</li>
                                        <div><span class="green"></span>
                                        		首先感谢您的支持和使用！<br />
												本系统为多管理操作系统！<br />
												支持批量管理  一键操作！<br />
												支持多服务器共读一个数据库！<br />
												支持一账号链接所有配置文件！<br />
												经过上个版本发出后的使用修复很多bug！<br />
												并开发全新后台UI界面 简介 方便操作！<br />
												康师傅官方团队感谢您的支持！<br />
												版本最后更新:2016.06.18！<br />
												
												</div>

                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--more statistics box end-->
                </div>
            </div>
            



                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--body wrapper end-->
<?php include 'footer.php';?>