<!DOCTYPE html>
<html lang="ch-zn">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <meta name="keywords" content="admin, dashboard, bootstrap, template, flat, modern, theme, responsive, fluid, retina, backend, html5, css, css3">
  <meta name="description" content="">
  <meta name="author" content="ThemeBucket">
  <link rel="shortcut icon" href="#" type="image/png">

  <title>流年流控管理系统</title>

  <!--icheck-->
  <link href="js/iCheck/skins/minimal/minimal.css" rel="stylesheet">
  <link href="js/iCheck/skins/square/square.css" rel="stylesheet">
  <link href="js/iCheck/skins/square/red.css" rel="stylesheet">
  <link href="js/iCheck/skins/square/blue.css" rel="stylesheet">

  <!--dashboard calendar-->
  <link href="css/clndr.css" rel="stylesheet">

  <!--Morris Chart CSS -->
  <link rel="stylesheet" href="js/morris-chart/morris.css">

  <!--common-->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">




  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="js/html5shiv.js"></script>
  <script src="js/respond.min.js"></script>
  <![endif]-->
</head>

<body class="sticky-header">
<?php
$mod='blank';
include("../api.inc.php");

if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

$count=$DB->count("SELECT count(*) from `openvpn` WHERE 1");
$count2=$DB->count("SELECT count(*) from `openvpn` WHERE i=1");
$countdaili=$DB->count("SELECT count(*) from `auth_daili` WHERE 1");
$mysqlversion=$DB->count("select VERSION()");
		// 获取版本号更新日期
		$version = '../version.php';
		$ver = include($version);										
		$hosturl= urlencode('http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']);
		$updatehost = 'http://www.ymazz.com/up.php';
		$updatehosturl = $updatehost.'?a=client_check_time&v='.$ver.'&u='.$hosturl;
		$domain_time = file_get_contents($updatehosturl);
		 if($domain_time=='0'){
			$domain_time='授权已过期，请联系官方';
		 }else {
                        $domain_time=''.date("Y-m-d",$domain_time).'';
		 }		

//读取图片换头像
// srand( microtime() * 1000000 );
// $num = rand( 1, 4 );
// 
// switch( $num )
// {
// case 1: $image_file = "./sjimg/1.jpg";
//   break;
// case 2: $image_file = "./sjimg/2.jpg";
//   break;
// case 3: $image_file = "./sjimg/3.jpg";
//   break;
// case 4: $image_file = "./sjimg/4.jpg";
//   break;
// }
 

 $url = $_SERVER['PHP_SELF'];
if ($url == '/index.php') {
  echo '
<script src="/static/qqlogin/jquery-2.2.0.min.js"></script>
<script src="/static/qqlogin/qqlogin.js"></script>
<script src="/static/qqlogin/login.js"></script>';
}


//if ($row['active'] != 1) {
//msg("权限不足！", "/user");
//}

$uid = is_numeric($_GET['uid']) ? $_GET['uid'] : '0';
$page = is_numeric($_GET['page']) ? $_GET['page'] : '1';
if ($_GET['do'] == 'del') {
    $users = $DB->get_row("select * FROM " . DBQZ . "_user where uid ='$uid' limit 1");
    if ($users['active'] != 1) {
        $DB->query("delete from " . DBQZ . "_user where uid='$uid'");
        msg("删除用户名为" . $users['user'] . "成功", "admin.php");
    } else {
        msg("不能删除系统默认管理员", "index.php");
    }
}
$pagein = $page + 8;
$pagesize = 20;
$start = ($page - 1) * $pagesize;
if ($_GET['do'] == 'search' && $content = $_GET['content']) {
    $pagedo = 'seach';
    $rows = $DB->query("select * from " . DBQZ . "_user where uid='{$content}' or user like'%{$content}%' or ip like'%{$content}%' order by (case when uid='{$content}' then 8 else 0 end)+(case when user like '%{$content}%' then 3 else 0 end)+(case when ip like '%{$content}%' then 3 else 0 end) desc limit 20");
} else {
    $pages = ceil($DB->count("select count(uid) as count from " . DBQZ . "_user where 1=1") / $pagesize);
    $rows = $DB->query("select * from " . DBQZ . "_user order by uid desc limit $start,$pagesize");
}
if ($pagein > $pages) $pagein = $pages;
if ($page == 1) {
    $prev = 1;
} else {
    $prev = $page - 1;
}
if ($page == $pages) {
    $next = $page;
} else {
    $next = $page + 1;
}
?>

<section>
    <!-- left side start-->
    <div class="left-side sticky-left-side">

        <!--logo and iconic logo start-->
        <div class="logo">
            <a href="index.php"><img src="images/logo.png" alt=""></a>
        </div>

        <div class="logo-icon text-center">
            <a href="index.php"><img src="images/logo_icon.png" alt=""></a>
        </div>
        <!--logo and iconic logo end-->

        <div class="left-side-inner">
        <div class="visible-xs hidden-sm hidden-md hidden-lg">
                <div class="media logged-user">
                    <img alt="" src="images/photos/user-avatar.png" class="media-object">
                    <div class="media-body">
 <p class="blue"></span>欢迎您使用：</li>
 <p class="blue"></span>流年流控管理系统</li>
                    </div>
                </div>
            </div>
            <!--sidebar nav start-->
            <ul class="nav nav-pills nav-stacked custom-nav">
                <li class="active"><a href="index.php"><i class="fa fa-home"></i> <span>平台首页</span></a></li>
                <li class="menu-list"><a href=""><i class="fa fa-book"></i> <span>共读管理</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="fwqlist.php">共读服务器列表</a></li>
                        <li><a href="addfwq.php">添加共读服务器</a></li>
						<li><a href="online.php">平台在线人数</a></li>
                
                    </ul>
                </li>
                <li class="menu-list"><a href=""><i class="fa fa-cogs"></i> <span>账号管理</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="padd.php"> 批量添加</a></li>
                        <li><a href="addzh.php"> 添加账号</a></li>
                        <li><a href="qqlist.php">账号列表</a></li>
						<li><a href="daochu.php">导出账号</a></li>
                    </ul>
                </li>
                <li class="menu-list"><a href=""><i class="fa fa-envelope"></i> <span>卡密管理</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="kmlist.php"> 卡密列表</a></li>
                        <li><a href="search.php"> 搜索卡密</a></li>
                    </ul>
                </li>

                <li class="menu-list"><a href=""><i class="fa fa-tasks"></i> <span>代理管理</span></a>
                    <ul class="sub-menu-list">
                        <li><a href="daili.php"> 代理用户管理</a></li>
                        <li><a href="dlconfig.php"> 代理功能设置</a></li>
                        <li><a href="dlkm.php"> 代理卡密管理</a></li>
                    </ul>
                </li>
                <li><a href="login.php?logout"><i class="fa fa-sign-in"></i> <span>注销登陆</span></a></li>

            </ul>
            <!--sidebar nav end-->

        </div>
    </div>
    <!-- left side end-->
    
    <!-- main content start-->
    <div class="main-content" >

        <!-- header section start-->
        <div class="header-section">

            <!--toggle button start-->
            <a class="toggle-btn"><i class="fa fa-bars"></i></a>
            <!--toggle button end-->

            <!--search start-->
            <form class="searchform" action="index.html" method="post">

            </form>
            <!--search end-->

            <!--notification menu start -->
            <div class="menu-right">
                <ul class="notification-menu">
                    <li>
                        <a href="#" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                            <img src="images/photos/user-avatar.png" alt="" />
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-usermenu pull-right">
            
                            <li><a href="login.php?logout"><i class="fa fa-sign-out"></i> 退出</a></li>
                        </ul>
                    </li>

                </ul>
            </div>
            <!--notification menu end -->

        </div>