<script language="javascript">
    window.location= "http://pay.25ak.com/";
</script>