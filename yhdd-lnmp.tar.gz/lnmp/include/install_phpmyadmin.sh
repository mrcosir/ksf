#!/bin/bash

# 安装phpmyadmin
cd /root/
curl -O http://kangml-10046394.file.myqcloud.com/phpMyAdmin-4.6.2-all-languages.tar.gz
tar -zxvf phpMyAdmin-4.6.2-all-languages.tar.gz -C /home/wwwroot/default/
rm -f phpMyAdmin-4.6.2-all-languages.tar.gz 
