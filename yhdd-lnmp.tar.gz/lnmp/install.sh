#!/bin/bash

cur_dir=$(pwd)
echo "-----康师傅三分钟极速lnmp------"
echo "--------by:康师傅免流----------"
echo
echo "即将开始安装..."
export cur_dir
 mkdir -p /home/wwwroot/default
 mkdir -p /home/wwwlog/
./include/init.sh

./include/install_nginx.sh

./include/install_php.sh

./include/install_mysql.sh

./include/install_phpmyadmin.sh
